insert into departments (`Department`)
values 
("Direction"),
("Marketing"),
("Programmation"),
("Conciergerie"),
("Ressources humaines"),
("Soutien informatique");

insert into games (`Title`) values ("Sudoku");
