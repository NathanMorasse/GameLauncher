﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HourGlassUnlimited.Models
{
    public class RankingItem
    {
        public string PrimarySlot1 { get; set; }
        public string PrimarySlot2 { get; set; }
        public string PrimarySlot3 { get; set; }
        public string SecondarySlot1 { get; set; }
        public string SecondarySlot2 { get; set; }
    }
}
