﻿using HourGlassUnlimited.Games.Sudoku.DataAccesLayer.Factories.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HourGlassUnlimited.Games.Sudoku.DataAccesLayer.Factories
{
    public class ScoreFactory : FactoryBase
    {

    }
}
