Fait par : Mathias Lavoie et Nathan Morass (2133752 - 2133133)

Nombre d'interface : 7

Fonctionnalité :
	- Département : CRUD + Liste des locaux associés
	- Local : CRUD
	- Mobilier : CRUD